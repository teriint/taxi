<html>
    <body>
        <h1>404</h1>
        <a href="/">Вернуться</a>
    </body>
</html>